# BDD Proxy Development Lab

Use [claat](https://github.com/googlecodelabs/tools) to
generate static HTML site from the Markdown document.

    go get github.com/googlecodelabs/tools/claat

    claat export ./lab.md

This will create directory with static files. Serve it from any static file
webserver.
