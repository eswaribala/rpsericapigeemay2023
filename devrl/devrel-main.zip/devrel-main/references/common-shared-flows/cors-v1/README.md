# CORS shared flow

Shared flow to set CORS headers for API responses.

---

NOTE: Apigee X/hybrid 1.5 introduced a native [CORS Policy](https://cloud.google.com/apigee/docs/api-platform/reference/policies/cors-policy)
that can be used as an alternative to this shared flow.

---
