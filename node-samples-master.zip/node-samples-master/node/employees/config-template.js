/*
 * Copy this file to "config.js" and edit the defaults for your environment
 */

exports.organization = ORGANIZATION
exports.application = 'employees'
exports.clientId = CLIENT_ID
exports.clientSecret = CLIENT_SECRET
exports.username = 'demo'
exports.password = 'demo'
exports.tokenExpiration = 60000
exports.logging = true
